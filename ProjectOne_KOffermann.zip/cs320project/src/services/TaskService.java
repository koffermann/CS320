package services;

// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: Module Six - Project One



import java.util.ArrayList;

import model.Task;



public class TaskService {
	ArrayList<Task> tasks;

	public TaskService() {
		tasks = new ArrayList<>();
	}

	// Adding Task with unique ID
	
	public boolean addTask(Task taskID) {
		boolean contains = false;
		for (Task task: tasks) {
			if (task.getTaskID().equals(taskID)) {
				contains = true;
			}
		}

		if (!contains) {
			tasks.add(taskID);
			return true;
		} 
		else {
			return false;
		}
	}

	// Deleting Tasks
	
	public boolean deleteTask(String taskID) {
		for (Task task: tasks) {
			if (task.getTaskID().equals(taskID)) {
				tasks.remove(task);
				return true;
			}
		}
		return false;
	}
	
	// Updating Tasks

	   public boolean updateTask(String taskID, String taskName, String taskDesc) {
	       for (Task task : tasks) {
	           if (task.getTaskID().equals(taskID)) {
	        	   
	               if (!taskName.equals(""))
	            	   task.setTaskName(taskName);
	               
	               if (!taskDesc.equals(""))
	            	   task.setTaskDesc(taskDesc);

	               return true;
	           }
	       }

	       return false;
	   }


}
