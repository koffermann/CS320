package services;

// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: Module Six - Project One



import java.util.ArrayList;

import model.Appointment;



public class AppointmentService {
	ArrayList<Appointment> appts;

	public AppointmentService() {
		appts = new ArrayList<>();
	}

	// Adding Appointment with unique ID
	
	public boolean addAppt(Appointment apptID) {
		boolean contains = false;
		for (Appointment appt: appts) {
			if (appt.getApptID().equals(apptID)) {
				contains = true;
			}
		}

		if (!contains) {
			appts.add(apptID);
			return true;
		} 
		else {
			return false;
		}
	}

	// Deleting Tasks
	
	public boolean deleteAppt(String apptID) {
		for (Appointment appt: appts) {
			if (appt.getApptID().equals(apptID)) {
				appts.remove(appt);
				return true;
			}
		}
		return false;
	}


}
