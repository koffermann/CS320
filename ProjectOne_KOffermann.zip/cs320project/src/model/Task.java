package model;

// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: Module Six - Project One


public class Task {
	public String taskID;
	public String taskName;
	public String taskDesc;
	
// Task constructor
	
	public Task(String taskID, String taskName, String taskDesc) {
		
		// Task ID string no more than 10 characters that is not null and not updateable.
		if(taskID.length() > 10 || taskID == null) {
			throw new IllegalArgumentException("Please use less than 10 characters.");
		}
		
		// Task Name string is no more than 20 characters that is not null.
		if(taskName.length() > 20 || taskName == null) {
			throw new IllegalArgumentException("Please use less than 20 characters.");
		}
		
			// Task Description string field no longer than 50 characters. Field is not null.
		if(taskDesc.length() > 50 || taskDesc == null) {
			throw new IllegalArgumentException("Please use less than 50 characters.");
		}
		
		this.taskID = taskID;
		this.taskName = taskName;
		this.taskDesc = taskDesc;
		
	}
	
	
// Setters
	
	public void setTaskID(String taskID) {
		this.taskID = taskID;
	}
	
	
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	
	
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	
	
	
// Getters
	
	public String getTaskID() {
		return taskID;
	}
	
	public String getTaskName() {
		return taskName;
	}
	
	public String getTaskDesc() {
		return taskDesc;
	}

		
}
