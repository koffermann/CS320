package model;

// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: 5-1 Milestone - Appointment Service

import java.util.Date;

public class Appointment {
	private String apptID;
	private String apptDesc;
	private Date apptDate;
	
	public Appointment(String apptID, Date apptDate, String apptDesc) {
		
		// Appointment ID string no more than 10 characters that is not null and not updateable.
		if(apptID.length() > 10 || apptID == null) {
			throw new IllegalArgumentException("Please use less than 10 characters.");
		}
		
		// Appointment Date string is not in the past and it is not null.
		Date currentDate = new Date();

		if(apptDate == null || apptDate.before(currentDate)) {
			throw new IllegalArgumentException("Please use a valid date.");
		}
		
		else {
			
		}
		
		// Appointment Description no more than 50 characters that is not null.
	
		if(apptDesc.length() > 50 || apptDesc == null) {
				throw new IllegalArgumentException("Please use less than 50 characters.");
		}
			
		this.apptID = apptID;
		this.apptDate = apptDate;
		this.apptDesc = apptDesc;

		
	}
	
	
// Setters
	
	public void setApptID(String apptID) {
		this.apptID = apptID;
	}
	
	
	public void setApptDate(Date apptDate) {
		this.apptDate = apptDate;
	}
	
	
	public void setApptDesc(String apptDesc) {
		this.apptDesc = apptDesc;
	}
	
	
// Getters
	
	public String getApptID() {
		return apptID;
	}
	
	public Date getApptDate() {
		return apptDate;
	}
	
	public String getApptDesc() {
		return apptDesc;
	}

		
}
