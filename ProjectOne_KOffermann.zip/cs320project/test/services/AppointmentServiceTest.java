package services;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Test;
import java.util.Date;

import model.Appointment;

//Class: CS320 - Software Test Automation
//Name: Kerrian Offermann
//Assignment: Module Six - Project One


public class AppointmentServiceTest {
	
	// Test if we are able to add appointments
	@Test
	public void testAdd(){		
		AppointmentService appt = new AppointmentService();	
		Appointment test1 = new Appointment("002", new Date(), "Take car to shop");
		Appointment test2 = new Appointment("003", new Date(), "Take Link to the vet");
		assertEquals(true, appt.addAppt(test1));
		assertEquals(true, appt.addAppt(test2));
	}
	
	
	// Test if we are able to delete appointments
	@Test
	public void testDelete() {
		AppointmentService appt = new AppointmentService();
		Appointment test3 = new Appointment("004", new Date(), "Attend optional meeting");
		assertEquals(true, appt.addAppt(test3));
		assertEquals(true, appt.deleteAppt("004"));
	}
	


}