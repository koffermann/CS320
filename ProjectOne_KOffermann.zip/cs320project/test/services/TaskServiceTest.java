package services;

import static org.junit.Assert.*;
import org.junit.jupiter.api.Test;

import model.Task;


//Class: CS320 - Software Test Automation
//Name: Kerrian Offermann
//Assignment: Module Six - Project One


public class TaskServiceTest { 
	
	// Test if we are able to add tasks
	
	@Test
	public void testAdd(){
		TaskService task = new TaskService();	
		Task test1 = new Task("002", "Shopping", "Pick up groceries");
		Task test2 = new Task("003", "Homework", "Complete assignments");
		assertEquals(true, task.addTask(test1));
		assertEquals(true, task.addTask(test2));
	}
	
	// Test if we are able to delete tasks
	@Test
	public void testDelete() {
		TaskService task = new TaskService();
		Task test3 = new Task("004", "Cook", "Cook dinner");
		assertEquals(true, task.addTask(test3));
		assertEquals(true, task.deleteTask("004"));
	}
	
	// Test if we are able to update tasks
	@Test
	public void testUpdate() {
		TaskService task = new TaskService();
		assertEquals(false, task.updateTask("002", "Get groceries", "Pick up groceries"));
		assertEquals(false, task.updateTask("003", "Homework", "Complete homework and compare to rubric"));
	}

}