package model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: Module Six - Project One


public class TaskTest { 
	
	// Test if Task ID is too long	
	@Test
	void testTaskIDTooLong() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("000000000000000000000000000000000000000000000000001", "Repair vehicle", "Take vehicle to repair shop");
		});	
	}
	
	
	// Test if Task Name is too long	
	@Test
	void testTaskNameTooLong() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", "Since the vehicle is broken it will be taken to a shop", "Take vehicle to repair shop");
		});	
	}
	
	
	
	// Test if appointment description is too long
	@Test
	public void testTaskTaskTooLong() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("001", "Repair vehicle", "Take the car to the shop to be examined for any "
					+ "problems with the battery and spark plugs since it is not starting.");
		});	
	}
	

	
	// Test if Task ID is null
	@Test
	public void testTaskIDNull() {	
		Assertions.assertThrows(NullPointerException.class, () -> {
			new Task(null, "Repair vehicle", "Take vehicle to repair shop");
		});	
	}
	
	
	// Test if Task name is null
	@Test
	public void testTaskNameNull() {	
		Assertions.assertThrows(NullPointerException.class, () -> {
			new Task("001", null, "Take vehicle to repair shop");
		});	
	}
	
	
	// Test if Task description is null
	@Test
	public void testTaskDescNull() {	
		Assertions.assertThrows(NullPointerException.class, () -> {
			new Task("001", "Repair vehicle", null);
		});	
	}
	


}