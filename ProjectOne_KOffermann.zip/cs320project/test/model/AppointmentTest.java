package model;

import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

// Class: CS320 - Software Test Automation
// Name: Kerrian Offermann
// Assignment: Module Six - Project One


public class AppointmentTest { 
	
	// Test if appointment ID is too long	
	@Test
	public void testApptIDTooLong() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("00000000000000000001", new Date(01/01/23), "Repair car");
		});	
	}
	
	// Test if appointment description is too long
	@Test
	public void testApptDescTooLong() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", new Date(01/01/23), "Take the car to the shop to be examined for any "
					+ "problems with the battery and spark plugs since it is not starting.");
		});	
	}
	
	// Test if appointment date is incorrect (in the past)
	@Test
	public void testApptDateInThePast() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", new Date(01/01/01), "Repair car");
		});	
	}
	
	// Test if appointment ID is null
	@Test
	public void testApptIDNull() {	
		Assertions.assertThrows(NullPointerException.class, () -> {
			new Appointment(null, new Date(01/01/23), "Repair car");
		});	
	}
	
	// Test if appointment description is null
	@Test
	public void testApptDescNull() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", new Date(01/01/23), null);
		});	
	}
	
	// Test if appointment date is null
	@Test
	public void testApptDateNull() {	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("001", null, "Repair car");
		});	
	}
		
		



}